

def error_message(msg, code=400):
    return msg
